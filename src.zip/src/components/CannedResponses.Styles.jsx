import styled from 'react-emotion';

export const CannedResponsesStyles = styled('div')`
  .form {
    width: 100%;
    margin-bottom: 20px;
   

  }
  div.textbox {
    background-color: rgb(236, 236, 236);
    height: 59px;
    max-height: 100px;
    width: 311px;
    overflow: hidden scroll;
    border-radius: 28px;
    padding: 10px;
  }
  .button{
    

    height: 43PX;
    width: 17%;
    margin: 1px;
    background: lightslategrey;
}
   }
   
   .button > img {
    display:inline-block;
    vertical-align: middle;
    padding-right:10px;
    }
  .input-label {
    padding-left: 5px;
  }
  

`;
