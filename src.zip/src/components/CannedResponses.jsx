import React, { Fragment } from 'react';
import { connect } from 'react-redux';


import TextField from '@material-ui/core/TextField';

import { Actions, withTheme } from '@twilio/flex-ui';
import FormControl from '@material-ui/core/FormControl';
import InputLabel from '@material-ui/core/InputLabel';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import ListSubheader from '@material-ui/core/ListSubheader';
import { CannedResponsesStyles } from './CannedResponses.Styles';

import { makeStyles } from "@material-ui/core/styles";
import Parser from 'html-react-parser';

//lists
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import Cancel from '@material-ui/icons/Cancel';
import ListItemText from '@material-ui/core/ListItemText';
import Divider from '@material-ui/core/Divider';
import InboxIcon from '@material-ui/icons/Inbox';
import DraftsIcon from '@material-ui/icons/Drafts';
import Button from '@material-ui/core/Button';

import Popover from '@material-ui/core/Popover';

const ITEM_HEIGHT = 28;
const ITEM_PADDING_TOP = 8;

const text = {
  color: "black",
  fontWeight:"bolder",
  textDecoration: "underline",
  fontSize:18
};
const text1 = {
  color: "black",
  textDecoration: "underline"
  
};
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP

    },
  },
};

class CannedResponses extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      anchor: null,
      response: '',
      cannedarray: [],
      selectedmsg:"",
      isDisabled:true
    }
  }
  componentDidMount() {

    this.tick();

  }
  async tick() {
    const body = { WorkerSpaceSid: 'WS1003379bef66573a71bdb0a94e5ab5b9' };
    const options = {
      method: 'POST',
      body: new URLSearchParams(body),
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }
    };
    await fetch('http://drab-barracuda-8971.twil.io/response', options)
      .then(resp => resp.json())
      .then(data => {
        console.log(data, "datttttttttttt");
      
        this.setState({ cannedarray: data });
         
        // this.cannedarray=data;
   

      })
      .catch(err => {
        console.log(err)
      })



  }
//  replaceJSX(str, find, replace) {
//     let parts = str.split(find);
//     for(let i = 0, result = []; i < parts.length; i++) {
//         result.push(parts[i]);
//         result.push(replace);
//     }
//     return result;
// }
  replaceAll(string, search, replace) {
    return string.split(search).join(replace);
  }
 escapeRegExp(string) {
console.log(string,"strrrrrrrrrrrrrrrr")
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
     // $& means the whole matched string
  
  }
  
  
replacecanned(str, find, replace) {
  console.log(str,"strrrrrrr000")
    return str.replace(new RegExp(this.escapeRegExp(find), 'g'), replace);
  
  }
  handleChange = (event) => {
    // this.setState({isDisabled:true})
    console.log(event,"evennnnt")
    this.setState({ response: event, anchor: null ,selectedmsg:event,isDisabled:true});
    console.log(this.state.selectedmsg,"selectedddddddddddddddddddddddd")
    // let selectedmsg = event;
 
    // console.log(selectedmsg.split("(first name)"),"selllecteddddddd");
    // var firstnamecolor=<p style={{color:"red"}}>(first name)</p>
    if(event.includes('\n')){
      event= event.replace(/(?:\r\n|\r|\n)/g, "<br>");
    }
let msg1;
let msg2;
//the below line if you are not able to fetch first name
if (event.includes("(first name)")||event.includes("(insert ticket concern)"))
{
msg1 = this.replacecanned(event,'(first name)','<p style={{background:"red"}}>(first name)</p>');

 msg2 = this.replacecanned(msg1,'(insert ticket concern)','<span style={{color:"red"}}>(insert infromation)</span>')
 this.setState({selectedmsg:msg2})
  }
  else{
    this.setState({selectedmsg:event,isDisabled:false})
  }
console.log(msg1,"msggggggg")
console.log(msg2,"msggggggg")
//   this.state.selectedmsg = this.replacecanned(this.state.selectedmsg,"(first name)","<p style={{color:'red'}}>first name</p>")
// this.state.selectedmsg = this.replacecanned(this.state.selectedmsg,'(insert infromation)','<span style={{color:"red"}}>insert infromation</span>')

  
  console.log(this.state.selectedmsg,"selected msggggggg")
  
    // if (this.state.selectedmsg.includes("(first name)")) {

    //   this.state.selectedmsg = this.replaceAll(this.state.selectedmsg, "(first name)",`${this.props.agentname}`)

    // }
    // if (this.state.selectedmsg.includes("(insert ticket concern)")) {

    //  this.state.selectedmsg = this.replaceAll(this.state.selectedmsg, "(insert ticket concern)", `${this.props.agentname}`)

    // }
   

    // Actions.invokeAction("SetInputText", {


    //   channelSid: this.props.channelSid,
    //   body: this.state.selectedmsg 

     




    // });

  }

handleSubmit(){
  Actions.invokeAction("SendMessage", {
        
            channelSid: this.props.channelSid,
            body: this.state.selectedmsg
          });
}

  handleClick(ev) {
    console.log(ev,"currentttttt")
    this.setState({ anchor: ev.currentTarget })
    console.log(ev.currentTarget,"currentttttt11111")

  }



  handleChange1(event) {    this.setState({value: event.target.value});  }
  handleClose = () => {
  this.setState({ anchor :false})
  };
  handleTextarea(ev) {
  
    console.log(ev,"areeaaaaa")
    // this.setState({ anchor: ev.currentTarget })
    console.log(ev.target.value,"currentttttt2222222")
    if(ev.target.textContent.includes("(first name)")||ev.target.textContent.includes("(insert ticket concern)")||ev.target.textContent.includes("(")||ev.target.textContent.includes(")")){
//if keyword present make the isdisabled to true
this.setState({isDisabled:true})
    }
    else{
      //make is disabled false 
      this.setState({isDisabled:false})
    }


  }

  handleOnClick = () => {
    Actions.invokeAction('SendMessage', {
    channelSid: this.props.channelSid,
    body: this.state.selectedmsg
  });
}
handleChangeText = (ev) => {
  console.log(ev.currentTarget,"currentttttt2222222")
  if(ev.target.includes("(first name)")||ev.target.textContent.includes("(insert ticket concern)")||ev.target.textContent.includes("(")||ev.target.textContent.includes(")")){
//if keyword present make the isdisabled to true
this.setState({isDisabled:true})
  }
  else{
    //make is disabled false 
    this.setState({isDisabled:false})
  }
}

  render() {

    return (
      <CannedResponsesStyles>
        
        <FormControl className="form">
        <TextField id="outlined-multiline-static"
        type={this.props.inputType}
          multiline
          rows={3} value={this.state.selectedmsg} variant="standard" fullWidth onChange={this.handleChangeText.bind(this)}/>
        <Button variant="text" onClick={this.handleOnClick.bind(this)}>submit</Button>
         {/* <form style={{display:"flex"}}onSubmit={this.handleSubmit.bind(this)}>
         <code onInput={this.handleTextarea.bind(this)} style={{width:"100%", border:"1px solid black",height:"50px",overflowY:"scroll"}} suppressContentEditableWarning={true} contentEditable={true} value={this.state.selectedmsg }>
  <span   >{this.state.selectedmsg}</span>
 
</code> 
<button disabled={this.state.isDisabled} className="button">SEND</button>
      </form>   */}
         {/* <code style={{width:"100%", border:"1px solid black",height:"50px",overflowY:"scroll"}} suppressContentEditableWarning={true} contentEditable={true} value={this.state.selectedmsg }>
  <span   >{this.state.selectedmsg}</span>
</code> */}
    {/* <textarea id="txtComment" style={{height: "43px",overflowY:"auto",borderRadius:"10px",width:"82%"}} value={this.state.selectedmsg } ></textarea> */}
{/* </div> */}
          {/* <input style={{width:"80%",height:"50px",borderRadius:"10px"}} type="text"  value={this.state.selectedmsg }  onChange={this.handleChange1}/>       */}
        {/* <input type="submit" value="Submit" /> */}

          <Button onClick={this.handleClick.bind(this)} className="input-label" htmlFor="response">Canned Responses</Button>

          <Popover   PaperProps={{style: { width: '95%',height:'90%',border:"1px solid black" }}} anchorEl={this.state.anchor} open={!!this.state.anchor} onClose={this.handleClose}>
            <List component="nav">
              <ListItem style={{display:'flex', justifyContent:'flex-end'}} >
                <ListItemIcon onClick={() => this.setState({ anchor: null })}>
                  <Cancel></Cancel>
                </ListItemIcon>
              </ListItem>


              {this.state.cannedarray.map((c, i) => {



                return (
                  <>
                    <ListItem   >
                    <ListItemText primaryTypographyProps={{ style: text }}>{c.subtopics[0].topic}</ListItemText> </ListItem>
                      {/* <ListItemText key={i}><b>{c.subtopics[0].topic}</b></ListItemText> </ListItem> */}
                      {/* <ListItem button onClick={this.handleChange.bind(this, c.subtopics[0].topicdata)}><ListItemText>{c.subtopics[0].topicdata}</ListItemText> </ListItem> */}
                     
                     
                      <ListItem style={{marginTop:'10px'}} button onClick={this.handleChange.bind(this, c.subtopics[0].topicdata)}><ListItemText    >
                      <div dangerouslySetInnerHTML={{


__html: c.subtopics[0].topicdata


}}></div>
                    </ListItemText> 
                    </ListItem>
     



                    {c.subtopics?.slice(1).map((o, i) => {

                      return (<>
                        <ListItem  ><ListItemText  primaryTypographyProps={{ style: text1 }}>{o.heading}</ListItemText> </ListItem>
                        {/* <ListItem button onClick={this.handleChange.bind(this, o.data)}><ListItemText><p style={{color:"rgb(0, 0, 51)"}}>{o.data}</p> </ListItemText></ListItem> */}
                        <ListItem   button onClick={this.handleChange.bind(this, o.data)}><ListItemText>
                        <div  dangerouslySetInnerHTML={{

                  __html:o.data

                      }}></div>
                          
                    </ListItemText></ListItem>
                      </>
                      )

                    })}

                    <Divider style={{ background: 'black' }} variant="middle"  />
                  </>
                );

              })}


            </List>



          </Popover>



        </FormControl>
      </CannedResponsesStyles>
    )
  }
};

const mapStateToProps = (state, ownProps) => {
  let currentTask = false;
  state.flex.worker.tasks.forEach((task) => {
    if (ownProps.channelSid === task.attributes.channelSid) {
      currentTask = task;
    }
  })

  return {
    state,
    currentTask,
  }
}

export default connect(mapStateToProps)(withTheme(CannedResponses));
